import 'package:flutter/material.dart';
import 'package:flutter_application_1/iconpage.dart';

void main() {
  runApp(const MainApp());
}

final _formKey = GlobalKey<FormState>();
final TextEditingController _userController = TextEditingController();
final TextEditingController _passwordController = TextEditingController();

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Login Page'),
          backgroundColor: Colors.blue,
        ),
        body: Form(
          key: _formKey,
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: const [
                    FlutterLogo(),
                    SizedBox(width: 10),
                    Text("Flutter", style: TextStyle(fontSize: 30)),
                  ],
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 24.0, vertical: 12),
                  child: TextFormField(
                    controller: _userController,
                    decoration: InputDecoration(
                      labelText: "Usuário",
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Campo obrigatório';
                      }
                      return null;
                    },
                  ),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 24.0, vertical: 12),
                  child: TextFormField(
                    controller: _passwordController,
                    obscureText: true,
                    decoration: InputDecoration(
                      labelText: "Senha",
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Campo obrigatório';
                      }
                      return null;
                    },
                  ),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    shape: const StadiumBorder(),
                    backgroundColor: Colors.blue,
                  ),
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      if (_userController.text == 'admin' &&
                          _passwordController.text == '1234') {
                        // Se o login for bem-sucedido, redireciona para a próxima página
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const IconPage(),
                          ),
                        );
                      } else {
                        // Exibe SnackBar com mensagem de erro
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text("E-mail e/ou senha inválidos"),
                            duration: Duration(seconds: 3),
                          ),
                        );
                      }
                    }
                  },
                  child: const Text(
                    "Login",
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}